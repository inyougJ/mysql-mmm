package MMM::Monitor::Role;

use strict;
use warnings FATAL => 'all';
use MMM::Common::Role;

our $VERSION = '0.01';
our @ISA = qw(MMM::Common::Role);


1;
